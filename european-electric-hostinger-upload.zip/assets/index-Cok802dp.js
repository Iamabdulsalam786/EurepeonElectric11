const e=`<!-- banner-section -->\r
        <section class="banner-section banner-style-one p_relative">\r
            <div class="banner-carousel owl-theme owl-carousel owl-dots-none">\r
                <div class="slide-item p_relative pt_180">\r
                    <div class="image-layer p_absolute" style="background-image:url(/assets/images/service/residential-install.jpg)"></div>\r
                    <div class="shape hero-slide-shape">\r
                        <div class="shape-1 p_absolute l_0 b_0 z_2"></div>\r
                        <div class="shape-2 p_absolute l_0 t_0 z_2"></div>\r
                        <div class="shape-3 p_absolute l_0 t_0 z_2"></div>\r
                    </div>\r
                    <div class="auto-container">\r
                        <div class="content-box p_relative d_block z_5">\r
                            <h2 class="p_relative d_block fs_60 lh_70 fw_bold mb_18">Licensed <span>Electrical</span> Work You Can Trust</h2>\r
                            <p class="p_relative d_block fs_18">European Electric LLC delivers safe, code-compliant installations, rewiring, and upgrades for homes and businesses across Melbourne.</p>\r
                        </div> \r
                    </div>\r
                </div>\r
                <div class="slide-item p_relative pt_180">\r
                    <div class="image-layer p_absolute" style="background-image:url(/assets/images/service/commercial-tenant.jpg)"></div>\r
                    <div class="shape hero-slide-shape">\r
                        <div class="shape-1 p_absolute l_0 b_0 z_2"></div>\r
                        <div class="shape-2 p_absolute l_0 t_0 z_2"></div>\r
                        <div class="shape-3 p_absolute l_0 t_0 z_2"></div>\r
                    </div>\r
                    <div class="auto-container">\r
                        <div class="content-box p_relative d_block z_5">\r
                            <h2 class="p_relative d_block fs_60 lh_70 fw_bold mb_18">Residential &amp; <span>Commercial</span> Electrical Experts</h2>\r
                            <p class="p_relative d_block fs_18">European Electric LLC — from panel upgrades and lighting to tenant improvements and EV charging, one licensed team with upfront pricing and dependable results.</p>\r
                        </div> \r
                    </div>\r
                </div>\r
                <div class="slide-item p_relative pt_180">\r
                    <div class="image-layer p_absolute" style="background-image:url(/assets/images/service/panel-service.jpg)"></div>\r
                    <div class="shape hero-slide-shape">\r
                        <div class="shape-1 p_absolute l_0 b_0 z_2"></div>\r
                        <div class="shape-2 p_absolute l_0 t_0 z_2"></div>\r
                        <div class="shape-3 p_absolute l_0 t_0 z_2"></div>\r
                    </div>\r
                    <div class="auto-container">\r
                        <div class="content-box p_relative d_block z_5">\r
                            <h2 class="p_relative d_block fs_60 lh_70 fw_bold mb_18">Power Your <span>Project</span> with Confidence</h2>\r
                            <p class="p_relative d_block fs_18">European Electric LLC handles new construction, remodeling, safety upgrades, and service panel modernization — scheduled professionally and built to code.</p>\r
                        </div> \r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- banner-section end -->\r
\r
\r
        <!-- search-field -->\r
        <section class="search-field">\r
            <div class="auto-container">\r
                <div class="outer-container">\r
                    <div class="title-text centred p_relative d_block">\r
                        <h6>Request a Free Electrical Consultation</h6>\r
                    </div>\r
                    <div class="search-area">\r
                        <form action="/" method="post">\r
                            <div class="row clearfix">\r
                                <div class="col-lg-3 col-md-6 col-sm-12 form-group">\r
                                    <input type="text" name="name" placeholder="Your name" required>\r
                                </div>\r
                                <div class="col-lg-3 col-md-6 col-sm-12 form-group">\r
                                    <input type="email" name="email" placeholder="Your email" required>\r
                                </div>\r
                                <div class="col-lg-3 col-md-6 col-sm-12 form-group">\r
                                    <input type="text" name="phone" placeholder="Phone" required>\r
                                </div>\r
                                <div class="col-lg-3 col-md-6 col-sm-12 form-group">\r
                                    <div class="icon"><i class="icon-8"></i></div>\r
                                    <input type="text" name="date" placeholder="Date" id="datepicker">\r
                                </div>\r
                            </div>\r
                            <div class="btn-box">\r
                                <button type="submit" class="theme-btn btn-one">Request a Quote</button>\r
                            </div>\r
                        </form>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- search-field end -->\r
\r
\r
        <!-- about-section -->\r
        <section class="about-section sec-pad">\r
            <div class="pattern-layer" style="background-image: url(/assets/images/shape/shape-2.png);"></div>\r
            <div class="auto-container">\r
                <div class="row clearfix">\r
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">\r
                        <div class="image_block_eight">\r
                            <div data-animation-box class="image-box p_relative d_block">\r
                                <div class="shape">\r
                                    <div class="shape-1" style="background-image: url(/assets/images/shape/shape-45.png);"></div>\r
                                    <div class="shape-2" style="background-image: url(/assets/images/shape/shape-45.png);"></div>\r
                                </div>\r
                                <div class="icon-box float-bob-y"><img src="/assets/images/icons/icon-1.png" alt=""></div>\r
                                <figure class="overlay-anim-black-bg image image-1 overlay-animation" data-animation="overlay-animation"><img src="/assets/images/service/residential-install.jpg" alt="European Electric electrician at work"></figure>\r
                                <figure class="image image-2"><img src="/assets/images/service/panel-electrical.jpg" alt="Electrical panel upgrade service"></figure>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">\r
                        <div class="content_block_one">\r
                            <div class="content-box p_relative d_block ml_30">\r
                                <div class="sec-title p_relative mb_25">\r
                                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">European Electric LLC</h5>\r
                                    <h2 class="d_block fs_40 lh_50 fw_bold">Residential &amp; Commercial Electrical Services</h2>\r
                                </div>\r
                                <div class="text p_relative d_block mb_30">\r
                                    <p>European Electric LLC is a full-service electrical contractor for homeowners, property managers, and commercial clients. We handle installations, rewiring, panel upgrades, lighting, safety improvements, EV charging, and new construction — with clear communication and workmanship you can rely on.</p>\r
                                </div>\r
                                <div class="inner p_relative d_block mb_40">\r
                                    <div class="row clearfix">\r
                                        <div class="col-lg-6 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box"><i class="icon-9"></i></div>\r
                                                <h4>Panel &amp; Service Upgrades</h4>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-6 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box"><i class="icon-10"></i></div>\r
                                                <h4>Lighting &amp; EV Charging</h4>\r
                                            </div>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                                <ul class="list-style-one clearfix">\r
                                    <li>Residential wiring, rewiring, and installations</li>\r
                                    <li>Commercial tenant improvements and power systems</li>\r
                                    <li>New construction, remodeling, and safety upgrades</li>\r
                                </ul>\r
                                <figure class="signature" hidden><img src="/assets/images/icons/signature-1.png" alt=""></figure>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- about-section end -->\r
\r
\r
        <!-- feature-section -->\r
        <section class="feature-section feature-section--equal">\r
            <div class="outer-container p_relative pl_30 pr_30">\r
                <div class="row clearfix feature-cards-row">\r
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">\r
                        <div class="feature-block-one wow fadeInLeft" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block clearfix">\r
                                <figure class="image-box p_relative d_block"><img src="/assets/images/service/safety-upgrades.jpg" alt="Electrical safety upgrades"></figure>\r
                                <div class="content-box p_relative d_block">\r
                                    <div class="icon-box p_relative d_block fs_50 lh_50"><i class="icon-12"></i></div>\r
                                    <h3><a href="/#services-safety-upgrades">Safety Upgrades</a></h3><p>GFCI, AFCI, surge protection, and grounding improvements to protect your property.</p><div class="link"><a href="/#services-safety-upgrades"><span>View service</span><i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">\r
                        <div class="feature-block-one wow fadeInLeft" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block clearfix">\r
                                <figure class="image-box p_relative d_block"><img src="/assets/images/service/residential-install.jpg" alt="Residential electrical installation"></figure>\r
                                <div class="content-box p_relative d_block">\r
                                    <div class="icon-box p_relative d_block fs_50 lh_50"><i class="icon-13"></i></div>\r
                                    <h3><a href="/#services-residential">Residential Electrical</a></h3><p>Outlets, lighting, rewiring, ceiling fans, and code-compliant home installations.</p><div class="link"><a href="/#services-residential"><span>View service</span><i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 feature-block">\r
                        <div class="feature-block-one wow fadeInLeft" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block clearfix">\r
                                <figure class="image-box p_relative d_block"><img src="/assets/images/service/panel-electrical.jpg" alt="Electrical panel upgrade"></figure>\r
                                <div class="content-box p_relative d_block">\r
                                    <div class="icon-box p_relative d_block fs_50 lh_50"><i class="icon-14"></i></div>\r
                                    <h3><a href="/#services-panel-upgrades">Panel Upgrades</a></h3><p>Panel replacement, service capacity upgrades, and breaker modernization for safer power.</p><div class="link"><a href="/#services-panel-upgrades"><span>View service</span><i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- feature-section end -->\r
\r
\r
        <!-- service-section -->
        <div id="services-section-mount" data-react-services="true"></div>
        <!-- service-section end -->\r
\r
\r
        <!-- chooseus-section -->\r
        <section class="chooseus-section p_relative">\r
            <div class="pattern-layer" style="background-image: url(/assets/images/shape/shape-5.png);"></div>\r
            <div class="bg-layer"></div>\r
            <div class="outer-container p_relative">\r
                <div class="row clearfix">\r
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">\r
                        <div class="content_block_four">\r
                            <div class="content-box">\r
                                <div class="sec-title p_relative mb_30">\r
                                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Why Choose Us</h5>\r
                                    <h2 class="d_block fs_40 lh_50 fw_bold mb_25">Why Homeowners &amp; Businesses Choose European Electric LLC</h2>\r
                                    <p>Licensed electricians, transparent pricing, and dependable service for residential wiring, commercial build-outs, and EV charger installations across every project size.</p>\r
                                </div>\r
                                <div class="inner-box centred p_relative d_block">\r
                                    <div class="row clearfix">\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-21"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Transparent Pricing</h5>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-22"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Licensed Electricians</h5>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-23"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Free Estimation</h5>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-24"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Modern Equipment</h5>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-25"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Code-Compliant Work</h5>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 single-column">\r
                                            <div class="single-item">\r
                                                <div class="icon-box p_relative d_iblock w_80 h_80 lh_80 fs_40 centred b_radius_50 tran_5"><i class="icon-26"></i></div>\r
                                                <h5 class="fs_18 fw_sbold">Reliable Scheduling</h5>\r
                                            </div>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">\r
                        <div class="image_block_four">\r
                            <div class="image-box mt_8">\r
                                <div class="image-shape">\r
                                    <div class="shape-1" style="background-image: url(/assets/images/shape/shape-6.png);"></div>\r
                                    <div class="shape-2" style="background-image: url(/assets/images/shape/shape-7.png);"></div>\r
                                </div>\r
                                <div class="row clearfix">\r
                                    <div class="col-lg-6 col-md-6 col-sm-12 single-image">\r
                                        <figure class="image-1 p_relative d_block"><img src="/assets/images/service/residential-rewire.jpg" alt="Licensed electrician on a residential job site"></figure>\r
                                    </div>\r
                                    <div class="col-lg-6 col-md-6 col-sm-12 video-column">\r
                                        <div class="video-inner p_relative d_block">\r
                                            <figure class="image-2 p_relative d_block"><img src="/assets/images/service/panel-service.jpg" alt="Professional electrical panel and wiring work"></figure>\r
                                            <div class="video-btn">\r
                                                <a href="https://www.youtube.com/watch?v=nfP5N9Yc72A&amp;t=28s" class="lightbox-image" data-caption=""><i class="icon-27"></i></a>\r
                                            </div>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- chooseus-section end -->\r
\r
\r
        <!-- team-section: disabled -->\r
\r
\r
        <!-- project-section: hidden -->\r
\r
\r
        <!-- faq-section: temporarily disabled -->\r
\r
\r
        <!-- clients-section: disabled for live site -->\r
\r
\r
        <!-- testimonial-section -->\r
        <section class="testimonial-section p_relative testimonial-section--refined">\r
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(/assets/images/background/testimonial-bg.jpg);"></div>\r
            <div class="bg-layer-2" style="background-image: url(/assets/images/background/testimonial-bg-2.jpg);"></div>\r
            <div class="auto-container">\r
                <div class="row align-items-center clearfix">\r
                    <div class="col-lg-6 col-md-12 col-sm-12 title-column">\r
                        <div class="sec-title light p_relative mb_50">\r
                            <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Testimonials</h5>\r
                            <h2 class="d_block fs_40 lh_50 fw_bold">What Our Clients Say <br />About European Electric LLC.</h2>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-6 col-md-12 col-sm-12 testimonial-column">\r
                        <div class="testimonial-inner p_relative d_block ml_30">\r
                            <div class="single-item-carousel owl-carousel owl-dots-none nav-style-one">\r
                                <div class="testimonial-block-one">\r
                                    <div class="inner-box p_relative d_block testimonial-card">\r
                                        <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>\r
                                        <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>\r
                                        <p>European Electric LLC upgraded our panel and installed new lighting throughout our home. Professional, on time, and the work passed inspection without a single issue.</p>\r
                                        <div class="author-box author-box--text-only p_relative d_block">\r
                                            <h5>Sarah Mitchell</h5>\r
                                            <span class="designation p_relative d_block">Homeowner</span>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                                <div class="testimonial-block-one">\r
                                    <div class="inner-box p_relative d_block testimonial-card">\r
                                        <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>\r
                                        <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>\r
                                        <p>They handled a full tenant improvement wiring project for our retail space. Clear communication, fair pricing, and everything was completed ahead of schedule.</p>\r
                                        <div class="author-box author-box--text-only p_relative d_block">\r
                                            <h5>James Porter</h5>\r
                                            <span class="designation p_relative d_block">Commercial Property Manager</span>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                                <div class="testimonial-block-one">\r
                                    <div class="inner-box p_relative d_block testimonial-card">\r
                                        <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>\r
                                        <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>\r
                                        <p>From permit to Tesla charger install, the team made the whole process easy. Our Level 2 charger has worked flawlessly since day one.</p>\r
                                        <div class="author-box author-box--text-only p_relative d_block">\r
                                            <h5>Elena Rodriguez</h5>\r
                                            <span class="designation p_relative d_block">EV Charger Customer</span>\r
                                        </div>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- testimonial-section end -->\r
\r
\r
        <!-- pricing-section -->\r
        <section class="pricing-section pricing-section--quotes p_relative sec-pad centred" id="estimates">\r
            <div class="pattern-layer">\r
                <div class="pattern-1 float-bob-y" style="background-image: url(/assets/images/shape/shape-10.png);"></div>\r
                <div class="pattern-2" style="background-image: url(/assets/images/shape/shape-11.png);"></div>\r
            </div>\r
            <div class="auto-container">\r
                <div class="sec-title sec-title--compact p_relative mb_50 centred">\r
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Free Estimates</h5>\r
                    <h2 class="d_block fs_40 lh_50 fw_bold">Clear Quotes. No Hidden Fees.</h2>\r
                    <p class="fs_16 mt_15">Written estimates with itemized scope for every residential, commercial, and specialty project.</p>\r
                </div>\r
                <div class="row clearfix pricing-cards-row">\r
                    <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">\r
                        <div class="pricing-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">\r
                            <div class="pricing-table p_relative d_block">\r
                                <div class="inner-box p_relative d_block">\r
                                    <div class="light-icon"><img src="/assets/images/icons/icon-4.png" alt=""></div>\r
                                    <div class="table-header">\r
                                        <div class="icon-box"><i class="icon-34"></i></div>\r
                                        <h2>Residential</h2>\r
                                        <p>Home wiring, lighting, outlets, panel upgrades, and EV charger installation.</p>\r
                                    </div>\r
                                    <div class="table-content">\r
                                        <ul class="feature-list clearfix">\r
                                            <li><span>On-site scope review</span></li>\r
                                            <li><span>Outlet &amp; lighting installs</span></li>\r
                                            <li><span>Rewiring &amp; panel upgrades</span></li>\r
                                            <li><span>Smoke &amp; CO detectors</span></li>\r
                                            <li><span>Code-compliant work</span></li>\r
                                            <li><span>Written estimate</span></li>\r
                                        </ul>\r
                                    </div>\r
                                    <div class="table-footer">\r
                                        <a href="/appointment"><span>Get Residential Quote</span></a>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">\r
                        <div class="pricing-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">\r
                            <div class="pricing-table p_relative d_block">\r
                                <div class="inner-box p_relative d_block">\r
                                    <div class="light-icon"><img src="/assets/images/icons/icon-4.png" alt=""></div>\r
                                    <div class="table-header">\r
                                        <div class="icon-box"><i class="icon-35"></i></div>\r
                                        <h2>Commercial</h2>\r
                                        <p>Office build-outs, retail spaces, power systems, and commercial lighting upgrades.</p>\r
                                    </div>\r
                                    <div class="table-content">\r
                                        <ul class="feature-list clearfix">\r
                                            <li><span>Tenant improvements</span></li>\r
                                            <li><span>Power distribution</span></li>\r
                                            <li><span>Dedicated circuits</span></li>\r
                                            <li><span>LED &amp; emergency lighting</span></li>\r
                                            <li><span>Phased scheduling</span></li>\r
                                            <li><span>Written estimate</span></li>\r
                                        </ul>\r
                                    </div>\r
                                    <div class="table-footer">\r
                                        <a href="/appointment"><span>Get Commercial Quote</span></a>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">\r
                        <div class="pricing-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">\r
                            <div class="pricing-table p_relative d_block">\r
                                <div class="inner-box p_relative d_block">\r
                                    <div class="light-icon"><img src="/assets/images/icons/icon-4.png" alt=""></div>\r
                                    <div class="table-header">\r
                                        <div class="icon-box"><i class="icon-36"></i></div>\r
                                        <h2>Specialty</h2>\r
                                        <p>EV charging, lighting design, safety upgrades, and new construction electrical work.</p>\r
                                    </div>\r
                                    <div class="table-content">\r
                                        <ul class="feature-list clearfix">\r
                                            <li><span>EV charger installation</span></li>\r
                                            <li><span>Indoor &amp; outdoor lighting</span></li>\r
                                            <li><span>GFCI &amp; AFCI upgrades</span></li>\r
                                            <li><span>New construction wiring</span></li>\r
                                            <li><span>Permit coordination</span></li>\r
                                            <li><span>Written estimate</span></li>\r
                                        </ul>\r
                                    </div>\r
                                    <div class="table-footer">\r
                                        <a href="/appointment"><span>Get Specialty Quote</span></a>\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- pricing-section end -->\r
\r
\r
        <!-- contact-section (homepage) -->\r
        <section class="contact-page-premium contact-page-premium--compact contact-page-premium--home contact-page-premium--home-slim sec-pad" id="contact">\r
            <div class="auto-container">\r
                <div class="sec-title p_relative mb_50 centred contact-page-premium__home-head">\r
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Contact</h5>\r
                    <h2 class="d_block fs_40 lh_50 fw_bold">Get a Free Quote</h2>\r
                    <p class="fs_16 mt_15">Licensed electrical work in Melbourne — quick form, reply within one business day.</p>\r
                </div>\r
                <div class="contact-page-premium__layout contact-page-premium__layout--home">\r
                    <aside class="contact-page-premium__aside-card contact-page-premium__aside-card--side">\r
                        <p class="contact-page-premium__aside-label">Prefer to call?</p>\r
                        <a href="tel:+15104684495" class="contact-page-premium__phone-cta">\r
                            <i class="far fa-phone-alt"></i>\r
                            <span class="contact-page-premium__phone-cta-num">+1 (510) 468-4495</span>\r
                            <span class="contact-page-premium__phone-cta-hint">Mon–Fri · 8 AM – 5 PM</span>\r
                        </a>\r
                        <ul class="contact-page-premium__aside-list">\r
                            <li>\r
                                <i class="far fa-envelope"></i>\r
                                <div>\r
                                    <strong>Email</strong>\r
                                    <a href="mailto:info@europeanelectric.com">info@europeanelectric.com</a>\r
                                </div>\r
                            </li>\r
                            <li>\r
                                <i class="far fa-map-marker-alt"></i>\r
                                <div>\r
                                    <strong>Office</strong>\r
                                    <span>380 Albert St, Melbourne, VIC</span>\r
                                </div>\r
                            </li>\r
                        </ul>\r
                        <div class="contact-page-premium__aside-proof">\r
                            <h4>What happens next</h4>\r
                            <ol>\r
                                <li>We review your message</li>\r
                                <li>You get a written quote — no hidden fees</li>\r
                            </ol>\r
                        </div>\r
                        <figure class="contact-page-premium__aside-image contact-page-premium__aside-image--desktop">\r
                            <img src="/assets/images/service/panel-service.jpg" alt="Licensed electrician at work">\r
                        </figure>\r
                    </aside>\r
                    <div class="contact-page-premium__form-shell">\r
                        <form class="contact-quote-form contact-quote-form--compact" method="post" action="/contact" id="home-contact-form">\r
                            <div class="contact-quote-form__head">\r
                                <h3>Request your quote</h3>\r
                                <p>Only <span>3 required fields</span> — takes about a minute.</p>\r
                            </div>\r
                            <div class="row clearfix">\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="home-contact-name">Name <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="text" id="home-contact-name" name="username" placeholder="Your name" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="home-contact-phone">Phone <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="tel" id="home-contact-phone" name="phone" placeholder="Best number to reach you" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="home-contact-email">Email <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="email" id="home-contact-email" name="email" placeholder="you@email.com" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="home-contact-service">Service</label>\r
                                    <div class="contact-quote-form__select-wrap">\r
                                        <select class="contact-quote-form__select" id="home-contact-service" name="service">\r
                                            <option value="">What do you need?</option>\r
                                            <option value="residential">Residential Electrical</option>\r
                                            <option value="commercial">Commercial Electrical</option>\r
                                            <option value="ev-chargers">EV Charger Installation</option>\r
                                            <option value="lighting-solutions">Lighting Solutions</option>\r
                                            <option value="panel-upgrades">Panel Upgrades</option>\r
                                            <option value="safety-upgrades">Safety Upgrades</option>\r
                                            <option value="new-construction">New Construction</option>\r
                                            <option value="other">Other</option>\r
                                        </select>\r
                                        <i class="far fa-chevron-down contact-quote-form__select-icon" aria-hidden="true"></i>\r
                                    </div>\r
                                </div>\r
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                    <label for="home-contact-message">Brief project details <span class="contact-quote-form__req">*</span></label>\r
                                    <textarea id="home-contact-message" name="message" placeholder="e.g. panel upgrade, EV charger, rewiring — suburb &amp; timing if you know it." required=""></textarea>\r
                                </div>\r
                            </div>\r
                            <label class="contact-quote-form__consent">\r
                                <input type="checkbox" name="consent" value="yes" required="">\r
                                <span>OK to contact me about this enquiry.</span>\r
                            </label>\r
                            <div class="contact-quote-form__submit">\r
                                <button class="theme-btn btn-one contact-quote-form__btn" type="submit" name="submit-form">\r
                                    Get My Free Quote <i class="far fa-arrow-right"></i>\r
                                </button>\r
                                <p class="contact-quote-form__note"><i class="far fa-lock"></i> Private &amp; secure — no spam</p>\r
                            </div>\r
                        </form>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- contact-section end -->\r
\r
\r
        <!-- funfact-section -->\r
        <section class="funfact-section p_relative centred bg-color-2">\r
            <div class="auto-container">\r
                <div class="inner-container p_relative">\r
                    <div class="counter-block-one wow slideInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">\r
                        <div class="inner-box">\r
                            <div class="icon-box p_relative d_block fs_60"><i class="icon-38"></i></div>\r
                            <div class="count-outer count-box">\r
                                <span class="count-text" data-speed="1500" data-stop="50">50</span><span class="counter-suffix">+</span>\r
                            </div>\r
                            <p>Successful projects</p>\r
                        </div>\r
                    </div>\r
                    <div class="counter-block-one wow slideInUp animated" data-wow-delay="100ms" data-wow-duration="1500ms">\r
                        <div class="inner-box">\r
                            <div class="icon-box p_relative d_block fs_60"><i class="icon-39"></i></div>\r
                            <div class="count-outer count-box">\r
                                <span class="count-text" data-speed="1500" data-stop="50">50</span><span class="counter-suffix">+</span>\r
                            </div>\r
                            <p>Satisfied Clients</p>\r
                        </div>\r
                    </div>\r
                    <div class="counter-block-one wow slideInUp animated" data-wow-delay="200ms" data-wow-duration="1500ms">\r
                        <div class="inner-box">\r
                            <div class="icon-box p_relative d_block fs_60"><i class="icon-40"></i></div>\r
                            <div class="count-outer count-box">\r
                                <span class="count-text" data-speed="1500" data-stop="10">10</span>\r
                            </div>\r
                            <p>Experienced Staff</p>\r
                        </div>\r
                    </div>\r
                    <div class="counter-block-one wow slideInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">\r
                        <div class="inner-box">\r
                            <div class="icon-box p_relative d_block fs_60"><i class="icon-41"></i></div>\r
                            <div class="count-outer count-box">\r
                                <span class="count-text" data-speed="1500" data-stop="10">10</span><span class="counter-suffix counter-suffix--word"> years</span>\r
                            </div>\r
                            <p>Years of Experience</p>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- funfact-section -->\r
\r
\r
        <!-- news-section -->\r
        <section class="news-section news-section--insights p_relative sec-pad">\r
            <div class="auto-container">\r
                <div class="sec-title p_relative mb_50 centred">\r
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Latest News</h5>\r
                    <h2 class="d_block fs_40 lh_50 fw_bold">Electrical Tips &amp; <br />Project Insights</h2>\r
                </div>\r
                <div class="row clearfix news-cards-row">\r
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">\r
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block">\r
                                <figure class="image-box"><a href="/faq"><img src="/assets/images/service/panel-electrical.jpg" alt="Electrical panel upgrade"></a></figure>\r
                                <div class="lower-content p_relative d_block">\r
                                    <h3><a href="/faq">5 Signs You Need a Panel Upgrade</a></h3>\r
                                    <ul class="post-info clearfix">\r
                                        <li><i class="icon-42"></i>Electrical Safety</li>\r
                                        <li><i class="icon-43"></i>European Electric LLC</li>\r
                                    </ul>\r
                                    <p>Flickering lights, tripping breakers, and outdated panels are warning signs that your home may need a licensed upgrade.</p>\r
                                    <div class="link"><a href="/faq">Read more<i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">\r
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block">\r
                                <figure class="image-box"><a href="/#services-ev-chargers"><img src="/assets/images/service/ev-charging.jpg" alt="EV charger installation"></a></figure>\r
                                <div class="lower-content p_relative d_block">\r
                                    <h3><a href="/#services-ev-chargers">Planning a Home EV Charger Install</a></h3>\r
                                    <ul class="post-info clearfix">\r
                                        <li><i class="icon-42"></i>EV Charging</li>\r
                                        <li><i class="icon-43"></i>European Electric LLC</li>\r
                                    </ul>\r
                                    <p>Learn what to expect with circuit sizing, panel capacity, and permit-ready Level 2 or Tesla charger installation at home.</p>\r
                                    <div class="link"><a href="/#services-ev-chargers">Read more<i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-4 col-md-6 col-sm-12 news-block">\r
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">\r
                            <div class="inner-box p_relative d_block">\r
                                <figure class="image-box"><a href="/#services-commercial"><img src="/assets/images/service/commercial-lighting.jpg" alt="Commercial electrical lighting"></a></figure>\r
                                <div class="lower-content p_relative d_block">\r
                                    <h3><a href="/#services-commercial">Commercial Lighting That Saves Energy</a></h3>\r
                                    <ul class="post-info clearfix">\r
                                        <li><i class="icon-42"></i>Commercial</li>\r
                                        <li><i class="icon-43"></i>European Electric LLC</li>\r
                                    </ul>\r
                                    <p>LED retrofits, warehouse lighting, and emergency lighting upgrades help businesses lower energy costs and stay compliant.</p>\r
                                    <div class="link"><a href="/#services-commercial">Read more<i class="icon-7"></i></a></div>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- news-section end -->\r
\r
\r
        <!-- subscribe-section -->\r
        <section class="subscribe-section subscribe-section--slim p_relative">\r
            <div class="auto-container">\r
                <div class="inner-container">\r
                    <div class="row align-items-center clearfix">\r
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">\r
                            <div class="text p_relative d_block">\r
                                <h2>Get Electrical Tips &amp; Project Updates</h2>\r
                            </div>\r
                        </div>\r
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">\r
                            <div class="form-inner p_relative d_block">\r
                                <form action="/" method="post">\r
                                    <div class="form-group">\r
                                        <input type="email" name="email" placeholder="Your email address" required="">\r
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- subscribe-section end -->`;export{e as default};
