const r=`<!-- Page Title -->\r
        <section class="page-title centred">\r
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(/assets/images/background/page-title.jpg);"></div>\r
            <div class="auto-container">\r
                <div class="content-box">\r
                    <h2>Page Not Found</h2>\r
                    <ul class="bread-crumb clearfix">\r
                        <li><a href="/">Home</a></li>\r
                        <li>404</li>\r
                    </ul>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- End Page Title -->\r
\r
\r
        <!-- error-section -->\r
        <section class="error-section centred p_relative">\r
            <div class="pattern-layer" style="background-image: url(/assets/images/shape/shape-48.png);"></div>\r
            <div class="auto-container">\r
                <div class="inner-box">\r
                    <figure class="error-image"><img src="/assets/images/icons/error-1.png" alt=""></figure>\r
                    <h2>This Page Could Not Be Found</h2>\r
                    <p>The page you requested may have moved or no longer exists. Return to the homepage or contact European Electric LLC for electrical service enquiries.</p>\r
                    <a href="/" class="theme-btn btn-one"><i class="icon-6"></i>Back to Homepage</a>\r
                    <a href="/contact" class="theme-btn btn-one">Contact Us</a>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- error-section end -->\r
\r
\r
        <!-- subscribe-section -->\r
        <section class="subscribe-section subscribe-section--slim p_relative">\r
            <div class="auto-container">\r
                <div class="inner-container">\r
                    <div class="row align-items-center clearfix">\r
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">\r
                            <div class="text p_relative d_block">\r
                                <h2>Get Electrical Tips &amp; Project Updates</h2>\r
                            </div>\r
                        </div>\r
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">\r
                            <div class="form-inner p_relative d_block">\r
                                <form action="/" method="post">\r
                                    <div class="form-group">\r
                                        <input type="email" name="email" placeholder="Your email address" required="">\r
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- subscribe-section end -->`;export{r as default};
