const e=`<!-- Page Title -->\r
        <section class="page-title centred">\r
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(/assets/images/background/page-title.jpg);"></div>\r
            <div class="auto-container">\r
                <div class="content-box">\r
                    <h2>Get a Quote</h2>\r
                    <ul class="bread-crumb clearfix">\r
                        <li><a href="/">Home</a></li>\r
                        <li>Get a Quote</li>\r
                    </ul>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- End Page Title -->\r
\r
\r
        <!-- appointment-section -->\r
        <section class="appointment-section p_relative sec-pad">\r
            <div class="auto-container">\r
                <div class="sec-title p_relative mb_40 centred">\r
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Free Estimate</h5>\r
                    <h2 class="d_block fs_30 lh_40 fw_bold mb_25">Request Your Electrical Project Quote</h2>\r
                    <p>Tell us about your residential, commercial, or specialty electrical project. <br />We respond within one business day with clear next steps and a transparent quote path.</p>\r
                </div>\r
                <div class="form-inner">\r
                    <div class="content_block_13">\r
                        <div class="content-box p_relative d_block">\r
                            <div class="form-inner">\r
                                <form action="/contact" method="post">\r
                                    <div class="row clearfix">\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <input type="text" name="name" placeholder="Full name" required="">\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <input type="email" name="email" placeholder="Email address" required="">\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <input type="tel" name="phone" placeholder="Phone number" required="">\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <input type="text" name="address" placeholder="Job address or suburb" required="">\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <div class="select-box">\r
                                                <select class="wide" name="service" required>\r
                                                   <option data-display="Select service">Select service</option>\r
                                                   <option value="residential">Residential Electrical</option>\r
                                                   <option value="commercial">Commercial Electrical</option>\r
                                                   <option value="ev-chargers">EV Charger Installation</option>\r
                                                   <option value="lighting-solutions">Lighting Solutions</option>\r
                                                   <option value="panel-upgrades">Panel Upgrades</option>\r
                                                   <option value="safety-upgrades">Safety Upgrades</option>\r
                                                   <option value="new-construction">New Construction &amp; Remodeling</option>\r
                                                   <option value="other">Other / Not Sure</option>\r
                                                </select>\r
                                            </div>\r
                                        </div>\r
                                        <div class="col-lg-4 col-md-6 col-sm-12 form-group">\r
                                            <div class="icon"><i class="icon-75"></i></div>\r
                                            <input type="text" name="date" placeholder="Preferred start date (optional)" id="datepicker">\r
                                        </div>\r
                                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                            <textarea name="message" placeholder="Describe your project — scope, timeline, access notes, or any panel/lighting details..." required=""></textarea>\r
                                        </div>\r
                                        <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                            <div class="message-btn centred">\r
                                                <button type="submit" class="theme-btn btn-one">Get My Free Quote</button>\r
                                            </div>\r
                                        </div>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- appointment-section end -->\r
\r
\r
        <!-- subscribe-section -->\r
        <section class="subscribe-section subscribe-section--slim p_relative">\r
            <div class="auto-container">\r
                <div class="inner-container">\r
                    <div class="row align-items-center clearfix">\r
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">\r
                            <div class="text p_relative d_block">\r
                                <h2>Get Electrical Tips &amp; Project Updates</h2>\r
                            </div>\r
                        </div>\r
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">\r
                            <div class="form-inner p_relative d_block">\r
                                <form action="/" method="post">\r
                                    <div class="form-group">\r
                                        <input type="email" name="email" placeholder="Your email address" required="">\r
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- subscribe-section end -->\r
`;export{e as default};
