const e=`        <!-- contact-page-premium -->\r
        <section class="contact-page-premium contact-page-premium--compact">\r
            <div class="contact-page-premium__hero">\r
                <div class="auto-container">\r
                    <div class="contact-page-premium__hero-inner">\r
                        <div class="contact-page-premium__hero-copy">\r
                            <span class="contact-page-premium__eyebrow">Contact</span>\r
                            <h2>Get a Free Quote</h2>\r
                            <p>Licensed electrical work in Melbourne — quick form, clear written estimate.</p>\r
                        </div>\r
                        <div class="contact-page-premium__hero-trust contact-page-premium__hero-trust--compact">\r
                            <span class="contact-page-premium__hero-trust-item"><i class="far fa-clock"></i> 1-day reply</span>\r
                            <span class="contact-page-premium__hero-trust-item"><i class="far fa-shield-check"></i> Licensed</span>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
\r
            <div class="auto-container">\r
                <div class="contact-page-premium__layout">\r
                    <aside class="contact-page-premium__aside-card contact-page-premium__aside-card--side">\r
                        <p class="contact-page-premium__aside-label">Prefer to call?</p>\r
                        <a href="tel:+15104684495" class="contact-page-premium__phone-cta">\r
                            <i class="far fa-phone-alt"></i>\r
                            <span class="contact-page-premium__phone-cta-num">+1 (510) 468-4495</span>\r
                            <span class="contact-page-premium__phone-cta-hint">Mon–Fri · 8 AM – 5 PM</span>\r
                        </a>\r
                        <ul class="contact-page-premium__aside-list">\r
                            <li>\r
                                <i class="far fa-envelope"></i>\r
                                <div>\r
                                    <strong>Email</strong>\r
                                    <a href="mailto:info@europeanelectric.com">info@europeanelectric.com</a>\r
                                </div>\r
                            </li>\r
                            <li>\r
                                <i class="far fa-map-marker-alt"></i>\r
                                <div>\r
                                    <strong>Office</strong>\r
                                    <span>380 Albert St, Melbourne, VIC</span>\r
                                </div>\r
                            </li>\r
                        </ul>\r
                        <div class="contact-page-premium__aside-proof">\r
                            <h4>What happens next</h4>\r
                            <ol>\r
                                <li>We review your message</li>\r
                                <li>You get a written quote — no hidden fees</li>\r
                            </ol>\r
                        </div>\r
                        <figure class="contact-page-premium__aside-image contact-page-premium__aside-image--desktop">\r
                            <img src="/assets/images/resource/contact-1.jpg" alt="European Electric electrician on site">\r
                        </figure>\r
                    </aside>\r
\r
                    <div class="contact-page-premium__form-shell">\r
                        <form class="contact-quote-form contact-quote-form--compact" method="post" action="/contact" id="contact-form">\r
                            <div class="contact-quote-form__head">\r
                                <h3>Request your quote</h3>\r
                                <p>Only <span>3 required fields</span> — takes about a minute.</p>\r
                            </div>\r
\r
                            <div class="row clearfix">\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="contact-name">Name <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="text" id="contact-name" name="username" placeholder="Your name" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="contact-phone">Phone <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="tel" id="contact-phone" name="phone" placeholder="Best number to reach you" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="contact-email">Email <span class="contact-quote-form__req">*</span></label>\r
                                    <input type="email" id="contact-email" name="email" placeholder="you@email.com" required="">\r
                                </div>\r
                                <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                    <label for="contact-service">Service</label>\r
                                    <div class="contact-quote-form__select-wrap">\r
                                        <select class="contact-quote-form__select" id="contact-service" name="service">\r
                                            <option value="">What do you need?</option>\r
                                            <option value="residential">Residential Electrical</option>\r
                                            <option value="commercial">Commercial Electrical</option>\r
                                            <option value="ev-chargers">EV Charger Installation</option>\r
                                            <option value="lighting-solutions">Lighting Solutions</option>\r
                                            <option value="panel-upgrades">Panel Upgrades</option>\r
                                            <option value="safety-upgrades">Safety Upgrades</option>\r
                                            <option value="new-construction">New Construction</option>\r
                                            <option value="other">Other</option>\r
                                        </select>\r
                                        <i class="far fa-chevron-down contact-quote-form__select-icon" aria-hidden="true"></i>\r
                                    </div>\r
                                </div>\r
                                <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                    <label for="contact-message">Brief project details <span class="contact-quote-form__req">*</span></label>\r
                                    <textarea id="contact-message" name="message" placeholder="e.g. panel upgrade, EV charger, rewiring — suburb &amp; timing if you know it." required=""></textarea>\r
                                </div>\r
                            </div>\r
\r
                            <label class="contact-quote-form__consent">\r
                                <input type="checkbox" name="consent" value="yes" required="">\r
                                <span>OK to contact me about this enquiry.</span>\r
                            </label>\r
\r
                            <div class="contact-quote-form__submit">\r
                                <button class="theme-btn btn-one contact-quote-form__btn" type="submit" name="submit-form">\r
                                    Get My Free Quote <i class="far fa-arrow-right"></i>\r
                                </button>\r
                                <p class="contact-quote-form__note"><i class="far fa-lock"></i> Private &amp; secure — no spam</p>\r
                            </div>\r
                        </form>\r
                    </div>\r
                </div>\r
            </div>\r
\r
            <div class="contact-page-premium__map-wrap">\r
                <div class="auto-container">\r
                    <div class="contact-page-premium__map-head">\r
                        <h3>Find us in Melbourne</h3>\r
                    </div>\r
                    <div class="contact-page-premium__map">\r
                        <div class="map-inner p_relative d_block">\r
                            <div\r
                                class="google-map"\r
                                id="contact-google-map"\r
                                data-map-lat="-37.8136"\r
                                data-map-lng="144.9631"\r
                                data-icon-path="assets/images/icons/map-marker.png"\r
                                data-map-title="European Electric LLC — Melbourne"\r
                                data-map-zoom="14"\r
                                data-markers='{\r
                                    "marker-1": [-37.8136, 144.9631, "<h4>European Electric LLC</h4><p>380 Albert St, Melbourne, VIC</p>","assets/images/icons/map-marker.png"]\r
                                }'>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- contact-page-premium end -->\r
\r
\r
        <!-- subscribe-section -->\r
        <section class="subscribe-section subscribe-section--slim p_relative">\r
            <div class="auto-container">\r
                <div class="inner-container">\r
                    <div class="row align-items-center clearfix">\r
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">\r
                            <div class="text p_relative d_block">\r
                                <h2>Get Electrical Tips &amp; Project Updates</h2>\r
                            </div>\r
                        </div>\r
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">\r
                            <div class="form-inner p_relative d_block">\r
                                <form action="/" method="post">\r
                                    <div class="form-group">\r
                                        <input type="email" name="email" placeholder="Your email address" required="">\r
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- subscribe-section end -->\r
`;export{e as default};
