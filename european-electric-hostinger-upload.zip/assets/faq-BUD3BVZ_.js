const n=`<!-- Page Title -->\r
        <section class="page-title centred">\r
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(/assets/images/background/page-title.jpg);"></div>\r
            <div class="auto-container">\r
                <div class="content-box">\r
                    <h2>FAQ</h2>\r
                    <ul class="bread-crumb clearfix">\r
                        <li><a href="/">Home</a></li>\r
                        <li>FAQ</li>\r
                    </ul>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- End Page Title -->\r
\r
\r
        <!-- faq-page-section -->\r
        <section class="faq-page-section p_relative sec-pad">\r
            <div class="auto-container">\r
                <div class="sec-title p_relative centred mb_50">\r
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">FAQ</h5>\r
                    <h2 class="d_block fs_40 lh_50 fw_bold mb_25">Frequently Asked <br />Questions</h2>\r
                    <p>Answers to common questions about electrical services, pricing, scheduling, and working with European Electric LLC.</p>\r
                </div>\r
                <div class="row clearfix">\r
                    <div class="col-lg-6 col-md-6 col-sm-12 inner-column">\r
                        <div class="accordion-inner">\r
                            <ul class="accordion-box">\r
                                <li class="accordion block active-block">\r
                                    <div class="acc-btn active">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>Do you handle residential electrical work?</h5>\r
                                    </div>\r
                                    <div class="acc-content current">\r
                                        <div class="text">\r
                                            <p>Yes. We install outlets, switches, lighting, ceiling fans, smoke detectors, and complete whole-house or partial rewiring projects. We also handle residential panel upgrades, service entrance improvements, and EV charger installations for homeowners.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                                <li class="accordion block">\r
                                    <div class="acc-btn">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>Are you licensed and insured?</h5>\r
                                    </div>\r
                                    <div class="acc-content">\r
                                        <div class="text">\r
                                            <p>European Electric LLC is a licensed and insured electrical contractor. Our work is performed to applicable electrical codes, and we coordinate inspections when required for permits, panel upgrades, new circuits, and new construction projects.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                                <li class="accordion block">\r
                                    <div class="acc-btn">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>Do you provide free estimates?</h5>\r
                                    </div>\r
                                    <div class="acc-content">\r
                                        <div class="text">\r
                                            <p>Yes. We provide written estimates with itemized scope for residential, commercial, and specialty electrical projects. Request a quote through our appointment page or contact form and our team will follow up within one business day.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                            </ul>\r
                        </div>\r
                    </div>\r
                    <div class="col-lg-6 col-md-6 col-sm-12 inner-column">\r
                        <div class="accordion-inner">\r
                            <ul class="accordion-box">\r
                                <li class="accordion block">\r
                                    <div class="acc-btn">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>Do you work on commercial properties?</h5>\r
                                    </div>\r
                                    <div class="acc-content">\r
                                        <div class="text">\r
                                            <p>Absolutely. We support office build-outs, retail spaces, restaurants, warehouses, and tenant improvements — including power distribution, dedicated circuits, commercial lighting, LED retrofits, and emergency lighting upgrades.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                                <li class="accordion block">\r
                                    <div class="acc-btn">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>Can you install EV chargers at home?</h5>\r
                                    </div>\r
                                    <div class="acc-content">\r
                                        <div class="text">\r
                                            <p>Yes. We install Tesla and Level 2 home charging stations, including dedicated circuit installation, panel capacity review, and permit assistance. We help you choose the right setup for your vehicle and electrical service.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                                <li class="accordion block">\r
                                    <div class="acc-btn">\r
                                        <div class="icon-outer"><i class="far fa-angle-down"></i></div>\r
                                        <h5>How quickly can you schedule my project?</h5>\r
                                    </div>\r
                                    <div class="acc-content">\r
                                        <div class="text">\r
                                            <p>Scheduling depends on project scope and current workload. After your estimate is approved, we confirm a start date that works for your timeline. Our office hours are Mon–Fri, 8:00 AM – 5:00 PM, and we respond to all enquiries within one business day.</p>\r
                                        </div>\r
                                    </div>\r
                                </li>\r
                            </ul>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- faq-page-section -->\r
\r
\r
        <!-- contact-style-two -->\r
        <section class="contact-style-two pb_120 p_relative">\r
            <div class="bg-layer"></div>\r
            <div class="auto-container">\r
                <div class="col-lg-8 col-md-12 col-sm-12 offset-lg-2 inner-column">\r
                    <div class="inner-box">\r
                        <div class="sec-title p_relative mb_25 centred">\r
                            <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Still Have Questions?</h5>\r
                            <h2 class="d_block fs_30 lh_40 fw_bold">Ask Our Electrical Team</h2>\r
                            <p class="mt_15">Send your question and we will get back to you within one business day.</p>\r
                        </div>\r
                        <div class="content_block_13">\r
                            <div class="content-box p_relative d_block">\r
                                <div class="form-inner">\r
                                    <form action="/contact" method="post">\r
                                        <div class="row clearfix">\r
                                            <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                                <input type="text" name="name" placeholder="Your name" required="">\r
                                            </div>\r
                                            <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                                <input type="email" name="email" placeholder="Your email" required="">\r
                                            </div>\r
                                            <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                                <input type="text" name="phone" placeholder="Phone number" required="">\r
                                            </div>\r
                                            <div class="col-lg-6 col-md-6 col-sm-12 form-group">\r
                                                <div class="select-box">\r
                                                    <select class="wide" name="service">\r
                                                       <option data-display="Service topic">Service topic</option>\r
                                                       <option value="residential">Residential Electrical</option>\r
                                                       <option value="commercial">Commercial Electrical</option>\r
                                                       <option value="ev-chargers">EV Charger Installation</option>\r
                                                       <option value="lighting-solutions">Lighting Solutions</option>\r
                                                       <option value="panel-upgrades">Panel Upgrades</option>\r
                                                       <option value="safety-upgrades">Safety Upgrades</option>\r
                                                       <option value="new-construction">New Construction</option>\r
                                                       <option value="other">Other</option>\r
                                                    </select>\r
                                                </div>\r
                                            </div>\r
                                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                                <textarea name="message" placeholder="Your question in detail"></textarea>\r
                                            </div>\r
                                            <div class="col-lg-12 col-md-12 col-sm-12 form-group">\r
                                                <div class="message-btn centred">\r
                                                    <button type="submit" class="theme-btn btn-one">Send Your Question</button>\r
                                                </div>\r
                                            </div>\r
                                        </div>\r
                                    </form>\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- contact-style-two end -->\r
\r
\r
        <!-- subscribe-section -->\r
        <section class="subscribe-section subscribe-section--slim p_relative">\r
            <div class="auto-container">\r
                <div class="inner-container">\r
                    <div class="row align-items-center clearfix">\r
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">\r
                            <div class="text p_relative d_block">\r
                                <h2>Get Electrical Tips &amp; Project Updates</h2>\r
                            </div>\r
                        </div>\r
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">\r
                            <div class="form-inner p_relative d_block">\r
                                <form action="/" method="post">\r
                                    <div class="form-group">\r
                                        <input type="email" name="email" placeholder="Your email address" required="">\r
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>\r
                                    </div>\r
                                </form>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
        </section>\r
        <!-- subscribe-section end -->\r
`;export{n as default};
