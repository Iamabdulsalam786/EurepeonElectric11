const e=`<!-- Page Title -->
        <section class="page-title centred">
            <div class="bg-layer parallax-bg" data-parallax='{"y": 100}' style="background-image: url(/assets/images/background/page-title.jpg);"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h2>About Us</h2>
                    <ul class="bread-crumb clearfix">
                        <li><a href="/">Home</a></li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- about-section -->
        <section class="about-section sec-pad">
            <div class="pattern-layer-2" style="background-image: url(/assets/images/shape/shape-24.png);"></div>
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_eight">
                            <div data-animation-box class="image-box p_relative d_block">
                                <div class="shape">
                                    <div class="shape-1" style="background-image: url(/assets/images/shape/shape-45.png);"></div>
                                    <div class="shape-2" style="background-image: url(/assets/images/shape/shape-45.png);"></div>
                                </div>
                                <div class="icon-box float-bob-y"><img src="/assets/images/icons/icon-1.png" alt=""></div>
                                <figure data-animation-text class="overlay-anim-black-bg image image-1" data-animation="overlay-animation"><img src="/assets/images/service/residential-install.jpg" alt="Residential electrical installation"></figure>
                                <figure class="image image-2"><img src="/assets/images/service/panel-electrical.jpg" alt="Electrical panel upgrade"></figure>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_one">
                            <div class="content-box p_relative d_block ml_30">
                                <div class="sec-title p_relative mb_25">
                                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">About Us</h5>
                                    <h2 class="d_block fs_40 lh_50 fw_bold">Residential & Commercial Electrical Services</h2>
                                </div>
                                <div class="text p_relative d_block mb_30">
                                    <p>European Electric LLC is a full-service electrical contractor serving homeowners, property managers, and commercial clients across Melbourne. We specialize in safe, code-compliant work — from everyday installations to complex panel upgrades, tenant build-outs, and EV charging projects.</p>
                                    <p class="mt_15">Our team focuses on clear communication, upfront pricing, and workmanship that passes inspection the first time. Whether you are remodeling a kitchen, opening a retail space, or modernizing an older home, we deliver electrical solutions built to last.</p>
                                </div>
                                <div class="inner p_relative d_block mb_40">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-6 col-sm-12 single-column">
                                            <div class="single-item">
                                                <div class="icon-box"><i class="icon-9"></i></div>
                                                <h4>Licensed &amp; Insured</h4>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 single-column">
                                            <div class="single-item">
                                                <div class="icon-box"><i class="icon-10"></i></div>
                                                <h4>Written Estimates</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <ul class="list-style-one clearfix">
                                    <li>Residential wiring, rewiring, and installations</li>
                                    <li>Commercial tenant improvements and power systems</li>
                                    <li>EV charging, lighting, panels, and new construction</li>
                                </ul>
                                <figure class="signature" hidden><img src="/assets/images/icons/signature-1.png" alt=""></figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-section end -->


        <!-- about-popular-services -->
        <section class="about-services-premium sec-pad">
            <div class="auto-container">
                <div class="about-services-premium__head centred">
                    <span class="about-services-premium__eyebrow">Our Services</span>
                    <h2 class="about-services-premium__title">Most Popular Electrical Services</h2>
                    <p class="about-services-premium__lead">Licensed work for homes, businesses, and specialty projects — explore what we deliver most often for our clients.</p>
                </div>
                <div class="about-services-premium__grid">
                    <article class="about-service-card">
                        <a href="/#services-residential" class="about-service-card__media"><img src="/assets/images/service/residential-install.jpg" alt="Residential electrical installations"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-residential">Residential Electrical</a></h3>
                            <p>Installations, rewiring, outlets, fixtures, and panel upgrades for homes.</p>
                            <a href="/#services-residential" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                    <article class="about-service-card">
                        <a href="/#services-commercial" class="about-service-card__media"><img src="/assets/images/service/commercial-tenant.jpg" alt="Commercial electrical services"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-commercial">Commercial Electrical</a></h3>
                            <p>Tenant improvements, power systems, and commercial lighting for business spaces.</p>
                            <a href="/#services-commercial" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                    <article class="about-service-card">
                        <a href="/#services-ev-chargers" class="about-service-card__media"><img src="/assets/images/service/ev-charging.jpg" alt="EV charger installation"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-ev-chargers">EV Charger Installation</a></h3>
                            <p>Level 2 home charging, circuit installs, and permit-ready EV setups.</p>
                            <a href="/#services-ev-chargers" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                    <article class="about-service-card">
                        <a href="/#services-panel-upgrades" class="about-service-card__media"><img src="/assets/images/service/panel-electrical.jpg" alt="Electrical panel upgrades"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-panel-upgrades">Panel Upgrades</a></h3>
                            <p>Panel replacement, service capacity upgrades, and breaker modernization.</p>
                            <a href="/#services-panel-upgrades" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                    <article class="about-service-card">
                        <a href="/#services-lighting-solutions" class="about-service-card__media"><img src="/assets/images/service/lighting-indoor.jpg" alt="Lighting solutions"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-lighting-solutions">Lighting Solutions</a></h3>
                            <p>Indoor recessed lighting, outdoor security lighting, and LED retrofits.</p>
                            <a href="/#services-lighting-solutions" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                    <article class="about-service-card">
                        <a href="/#services-new-construction" class="about-service-card__media"><img src="/assets/images/service/new-construction.jpg" alt="New construction electrical"></a>
                        <div class="about-service-card__body">
                            <h3><a href="/#services-new-construction">New Construction</a></h3>
                            <p>New build wiring, remodel electrical, and ADU installations to code.</p>
                            <a href="/#services-new-construction" class="about-service-card__link">View service <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </article>
                </div>
                <div class="about-services-premium__cta centred">
                    <a href="/#services" class="theme-btn btn-one">View All Services</a>
                </div>
            </div>
        </section>
        <!-- about-popular-services end -->


        <!-- testimonial-style-two -->
        <section class="testimonial-style-two about-page p_relative">
            <div class="bg-layer"></div>
            <div class="auto-container">
                <div class="sec-title light p_relative mb_50 centred">
                    <h5 class="d_block fs_17 lh_25 fw_medium mb_9">Testimonials</h5>
                    <h2 class="d_block fs_40 lh_50 fw_bold">What Our Clients Say <br />About European Electric.</h2>
                </div>
                <div class="two-item-carousel owl-carousel owl-theme owl-nav-none">
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>European Electric upgraded our panel and installed new lighting throughout our home. Professional, on time, and the work passed inspection without a single issue.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-1.jpg" alt=""></figure>
                                <h5>Sarah Mitchell</h5>
                                <span class="designation p_relative d_block">Homeowner</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>They handled a full tenant improvement wiring project for our retail space. Clear communication, fair pricing, and everything was completed ahead of schedule.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-2.jpg" alt=""></figure>
                                <h5>James Porter</h5>
                                <span class="designation p_relative d_block">Commercial Property Manager</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>European Electric upgraded our panel and installed new lighting throughout our home. Professional, on time, and the work passed inspection without a single issue.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-1.jpg" alt=""></figure>
                                <h5>Sarah Mitchell</h5>
                                <span class="designation p_relative d_block">Homeowner</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>They handled a full tenant improvement wiring project for our retail space. Clear communication, fair pricing, and everything was completed ahead of schedule.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-2.jpg" alt=""></figure>
                                <h5>James Porter</h5>
                                <span class="designation p_relative d_block">Commercial Property Manager</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>European Electric upgraded our panel and installed new lighting throughout our home. Professional, on time, and the work passed inspection without a single issue.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-1.jpg" alt=""></figure>
                                <h5>Sarah Mitchell</h5>
                                <span class="designation p_relative d_block">Homeowner</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box p_relative d_block">
                            <div class="light-icon"><img src="/assets/images/icons/icon-3.png" alt=""></div>
                            <div class="icon-box p_relative d_block fs_65"><i class="icon-31"></i></div>
                            <p>They handled a full tenant improvement wiring project for our retail space. Clear communication, fair pricing, and everything was completed ahead of schedule.</p>
                            <div class="author-box p_relative d_block">
                                <figure class="author-thumb p_absolute l_0 t_0 w_70 h_70 b_radius_50"><img src="/assets/images/resource/testimonial-2.jpg" alt=""></figure>
                                <h5>James Porter</h5>
                                <span class="designation p_relative d_block">Commercial Property Manager</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- testimonial-style-two end -->


        <!-- working-style-two -->
        <section class="working-style-two p_relative sec-pad">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 title-column">
                         <div class="sec-title p_relative">
                            <h5 class="d_block fs_17 lh_25 fw_medium mb_9">How It Works</h5>
                            <h2 class="d_block fs_40 lh_50 fw_bold">3 Simple Steps to Work with European Electric</h2>
                        </div>
                    </div>
                </div>
                <div class="tabs-box">
                    <div class="tab-btn-box centred">
                        <ul class="tab-btns tab-buttons clearfix">
                            <li class="tab-btn" data-tab="#tab-1"><i class="icon-49"></i></li>
                            <li class="tab-btn active-btn" data-tab="#tab-2"><i class="icon-50"></i></li>
                            <li class="tab-btn" data-tab="#tab-3"><i class="icon-51"></i></li>
                        </ul>
                    </div>
                    <div class="tabs-content">
                        <div class="tab" id="tab-1">
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="text mr_30">
                                        <h3><i class="icon-45"></i>Request a Free Quote</h3>
                                        <p>Tell us about your project online or by phone. Share your service needs, property location, and timeline so we can route your request to the right licensed electrician.</p>
                                        <p>We respond within one business day with clear next steps — no vague callbacks or pressure sales tactics.</p>
                                        <a href="/appointment" class="theme-btn btn-one">Get a Quote</a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <div class="image-box ml_120">
                                        <div class="shape" style="background-image: url(/assets/images/shape/shape-33.png);"></div>
                                        <figure class="image"><img src="/assets/images/service/residential-install.jpg" alt="Request a free electrical quote"></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab active-tab" id="tab-2">
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="text mr_30">
                                        <h3><i class="icon-45"></i>Review Your Written Estimate</h3>
                                        <p>We provide an itemized scope with labor, materials, and code requirements explained in plain language. Residential, commercial, and specialty projects are quoted with upfront pricing.</p>
                                        <p>Once approved, we schedule work around your availability and keep you informed at every stage.</p>
                                        <a href="/contact" class="theme-btn btn-one">Contact Us</a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <div class="image-box ml_120">
                                        <div class="shape" style="background-image: url(/assets/images/shape/shape-33.png);"></div>
                                        <figure class="image"><img src="/assets/images/service/commercial-tenant.jpg" alt="Review your written electrical estimate"></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab" id="tab-3">
                            <div class="row clearfix">
                                <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                                    <div class="text mr_30">
                                        <h3><i class="icon-45"></i>Licensed Work &amp; Final Walkthrough</h3>
                                        <p>Our electricians complete installations, upgrades, and repairs to code — with testing, cleanup, and inspection support where required.</p>
                                        <p>Before we leave, we walk you through the finished work and answer any questions about your new electrical systems.</p>
                                        <a href="/#services" class="theme-btn btn-one">View Services</a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                                    <div class="image-box ml_120">
                                        <div class="shape" style="background-image: url(/assets/images/shape/shape-33.png);"></div>
                                        <figure class="image"><img src="/assets/images/service/panel-service.jpg" alt="Licensed electrical project completion"></figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- working-style-two end -->


        <!-- project-style-two -->
        <section class="project-style-two">
            <div class="outer-container">
                <div class="project-carousel-2 owl-carousel owl-theme owl-dots-none nav-style-one">
                    <div class="project-block-two">
                        <div class="inner-box">
                            <figure class="image-box"><img src="/assets/images/project/project-5.jpg" alt=""></figure>
                            <div class="view-btn"><a href="/assets/images/project/project-5.jpg" class="lightbox-image" data-fancybox="gallery"><i class="icon-28"></i></a></div>
                            <div class="text">
                                <h4>Whole-Home Rewiring</h4>
                                <span>Residential</span>
                            </div>
                        </div>
                    </div>
                    <div class="project-block-two">
                        <div class="inner-box">
                            <figure class="image-box"><img src="/assets/images/project/project-6.jpg" alt="Commercial tenant electrical build-out"></figure>
                            <div class="view-btn"><a href="/assets/images/project/project-6.jpg" class="lightbox-image" data-fancybox="gallery"><i class="icon-28"></i></a></div>
                            <div class="text">
                                <h4>Retail Tenant Build-Out</h4>
                                <span>Commercial</span>
                            </div>
                        </div>
                    </div>
                    <div class="project-block-two">
                        <div class="inner-box">
                            <figure class="image-box"><img src="/assets/images/project/project-7.jpg" alt="Panel upgrade project"></figure>
                            <div class="view-btn"><a href="/assets/images/project/project-7.jpg" class="lightbox-image" data-fancybox="gallery"><i class="icon-28"></i></a></div>
                            <div class="text">
                                <h4>200A Panel Upgrade</h4>
                                <span>Panel &amp; Service</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- project-style-two end -->


        <!-- team-section: disabled -->


        <!-- subscribe-section -->
        <section class="subscribe-section subscribe-section--slim p_relative">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="row align-items-center clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 text-column">
                            <div class="text p_relative d_block">
                                <h2>Get Electrical Tips &amp; Project Updates</h2>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 form-column">
                            <div class="form-inner p_relative d_block">
                                <form action="/" method="post">
                                    <div class="form-group">
                                        <input type="email" name="email" placeholder="Your email address" required="">
                                        <button type="submit">Subscribe Now<i class="icon-7"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- subscribe-section end -->`;export{e as default};
